<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JazakAllh Forget Password</title>
</head>
<body>
    <h1>Forget Your Password</h1>
    <p>You're receiving this email because you requested a password reset for your account.</p>
    <p>Your One-Time Password (OTP) is: <strong>{!! $otp_code !!}</strong></p>
    <p>If you didn't request a password reset, you can safely ignore this email.</p>
</body>
</html>